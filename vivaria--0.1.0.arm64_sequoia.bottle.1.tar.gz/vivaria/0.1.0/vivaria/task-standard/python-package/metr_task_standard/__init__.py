"""
A Python library for code shared between METR Task Standard tasks.
"""
