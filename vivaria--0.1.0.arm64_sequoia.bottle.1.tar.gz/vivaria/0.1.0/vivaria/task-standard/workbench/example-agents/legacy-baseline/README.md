# legacy-baseline

This is a simple agent based on the "basic" agent used in our internal experiments.

As written, this agent uses `gpt-4-0613` models, although it does not attempt to leverage the
"messages" format.

To use it with the workbench, pass `"pip install -r requirements.txt && env OPENAI_API_KEY='sk-...' python main.py"` as a command to `npm run agent`.
