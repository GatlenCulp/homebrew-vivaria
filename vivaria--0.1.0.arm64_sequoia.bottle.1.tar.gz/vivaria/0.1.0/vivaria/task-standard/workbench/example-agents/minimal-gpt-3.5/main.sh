#!/bin/sh
set -e
pip install openai python-dotenv
python main.py
