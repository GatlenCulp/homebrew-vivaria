# Example agents

The task standard tries to avoid constraining how agents are implemented. However, for ease of task development, the [workbench](..)'s `npm run agent` command supports running agents that are defined by a folder of source files and a command.

This folder contains five agents that follow this format. See each agent's README for more information.
