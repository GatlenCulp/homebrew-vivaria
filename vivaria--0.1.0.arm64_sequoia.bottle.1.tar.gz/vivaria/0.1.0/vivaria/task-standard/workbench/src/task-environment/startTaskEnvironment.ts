import { AuxVmDetails, Driver, Env, TaskSetupData, VmImageBuilder } from '../../../drivers/Driver'
import { addAuxVmDetailsToEnv } from './env'

export async function startTaskEnvironment(
  taskEnvironmentIdentifier: string,
  driver: Driver,
  taskFamilyDirectory: string,
  taskSetupData: TaskSetupData,
  env: Env,
  buildVmImage: VmImageBuilder,
  saveAuxVmDetails?: (auxVmDetails: AuxVmDetails | null) => Promise<void>,
): Promise<AuxVmDetails | null> {
  const auxVMDetails = await driver.maybeCreateAuxVm(
    taskEnvironmentIdentifier,
    taskFamilyDirectory,
    taskSetupData,
    buildVmImage,
  )
  await saveAuxVmDetails?.(auxVMDetails)

  // BEGIN-INTERNAL
  // taskSetupData.definition doesn't exist in the published Task Standard.
  if (taskSetupData.definition?.type !== 'inspect') {
    // END-INTERNAL
    await driver.startTask(taskSetupData, addAuxVmDetailsToEnv(env, auxVMDetails))
    // BEGIN-INTERNAL
  }
  // END-INTERNAL

  return auxVMDetails
}
