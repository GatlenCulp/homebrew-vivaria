echo "foo" >&2
echo "bar" 
echo "baz" >&2
