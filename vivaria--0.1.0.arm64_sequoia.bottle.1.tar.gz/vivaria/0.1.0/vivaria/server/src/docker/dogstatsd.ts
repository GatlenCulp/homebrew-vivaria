import { StatsD } from 'hot-shots'

export const dogStatsDClient = new StatsD({ globalTags: { env: process.env.NODE_ENV! } })
