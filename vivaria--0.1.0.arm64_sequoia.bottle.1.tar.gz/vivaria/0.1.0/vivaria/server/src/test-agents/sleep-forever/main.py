from pyhooks import Hooks
import time


hooks = Hooks()


async def main(*args):
    while True:
        time.sleep(1)


hooks.main(main)
