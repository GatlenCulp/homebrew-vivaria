from pyhooks import Hooks, MiddlemanSettings
import asyncio
import requests


hooks = Hooks()


async def main(*args):
    await hooks.submit("2")


hooks.main(main)
