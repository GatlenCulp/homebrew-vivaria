export const setup = () => {
  process.env.TZ = 'UTC' // ensure test behavior doesn't depend on the timezone set on the machine
}
