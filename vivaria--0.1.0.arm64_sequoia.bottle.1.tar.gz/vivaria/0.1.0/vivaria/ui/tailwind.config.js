/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,js,ts,tsx,mjs}'],
  theme: {
    extend: {},
  },
  plugins: [],
}
